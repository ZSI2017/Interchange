Zepto(function($){
	var orderNo =getUrlParam('orderNo');
	ant.call('setTitle', {
		title: '取消订单',
	});
});
