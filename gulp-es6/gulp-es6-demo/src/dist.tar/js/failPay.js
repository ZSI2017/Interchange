Zepto(function($){
	ant.call('setTitle', {
		title: '支付失败',
	});
});